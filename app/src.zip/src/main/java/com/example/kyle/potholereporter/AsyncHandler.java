package com.example.kyle.potholereporter;

public interface AsyncHandler {
    public abstract void handleResponse(String response);
}
