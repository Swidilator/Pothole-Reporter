package com.example.kyle.potholereporter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MunicipalActivity extends AppCompatActivity {

    private void processResults(String output){
        LinearLayout ll = (LinearLayout) findViewById(R.id.municipalLayout);
        try {
            JSONArray myArray = new JSONArray(output);
            for (int i = 0; i < myArray.length(); i++) {
                RelativeLayout rl = (RelativeLayout) getLayoutInflater().
                        inflate(R.layout.pothole_user, null);
                JSONObject jo = (JSONObject) myArray.get(i);
                final String id = jo.getString("P_NUM");
                String text = jo.getString("P_DATE");
                String date = jo.getString("P_LOC");
                if(jo.getString("P_FIX").equals("1")){
                    CheckBox c = (CheckBox)rl.findViewById(R.id.checkResolved);
                    c.setChecked(true);
                }

                TextView t;
                t = (TextView) rl.findViewById(R.id.textNumber);
                t.setText(id);
                t = (TextView) rl.findViewById(R.id.textDate);
                t.setText(text);
                t = (TextView) rl.findViewById(R.id.textCoord);
                t.setText(date);
                rl.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        System.out.println(id);
                    }
                });
                ll.addView(rl);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_municipal);


    }
}
